package com.schoolmanagment.schoolManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}

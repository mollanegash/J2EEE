package com.feems.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.feems.model.Fee;
import com.feems.repo.FeeRepository;

@Service
public class FeeService {
	@Autowired
	private FeeRepository feeRepository;

	public List<Fee> getAllFees() {
		List<Fee> fees = new ArrayList<>();
		feeRepository.findAll().forEach(fee -> fees.add(fee));
		
		return fees;

	}

//	public Fee getstudentById(int id) {
//		return studentRepository.findById(id).get();
//
//	}

	public Fee saveOrUpdateFee(Fee fee) {
		return feeRepository.save(fee);

	}

//	public void  deleteById(int id) {
//		// TODO Auto-generated method stub
//		studentRepository.deleteById(id);;
//	}
	

	

}

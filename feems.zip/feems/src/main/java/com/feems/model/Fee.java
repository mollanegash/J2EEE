package com.feems.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;




@Entity

public class Fee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private int id;

	private String senders_name;

	private String recievers_name;

	private int amt;

	Fee() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSenders_name() {
		return senders_name;
	}

	public void setSenders_name(String senders_name) {
		this.senders_name = senders_name;
	}

	public String getRecievers_name() {
		return recievers_name;
	}

	public void setRecievers_name(String recievers_name) {
		this.recievers_name = recievers_name;
	}

	public int getAmt() {
		return amt;
	}

	public void setAmt(int amt) {
		this.amt = amt;
	}

}

package com.feems;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import com.feems.controller.FeeController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

//import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableCaching
@EnableSwagger2
//@ComponentScan(basePackageClasses=FeeController.class)

public class Feems {
	//@Cacheable
	//@Bean
	
	public static void main(String[] args) {
		SpringApplication.run(Feems.class, args);
	}

}
